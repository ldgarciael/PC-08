﻿class Actividad2Semana10
{
    static void Main()
    {
        int sumaNumeros = 0;
        int [] numerosColocar = new int [8];
        bool salidaNumeros = false;
        for (int i= 0; i < 8; i++) {
            do{
                Console.WriteLine("Ingrese el numero ");
                if(int.TryParse(Console.ReadLine(), out int numeroaIngresar )){
                    numerosColocar [i] = numeroaIngresar ;
                    sumaNumeros = sumaNumeros + numeroaIngresar;  
                    salidaNumeros=true; 
                }      
                else {
                    Console.WriteLine("Vuelvalo a intentar..."); 
                }  
            }
        while (salidaNumeros==false);
        }
        Console.WriteLine("Valores ingresados: ");
        for (int b= 0; b < 8; b++) {
            Console.WriteLine($"{b + 1}. {numerosColocar [b]}");    
        }
        int promedio = sumaNumeros/8;
        Console.WriteLine($"La suma es: {sumaNumeros}");
        Console.WriteLine($"El promedio es: {promedio}");
        
    }
}